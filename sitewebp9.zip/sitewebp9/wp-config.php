<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'frederic' );

/** MySQL database password */
define( 'DB_PASSWORD', 'frederic' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ')<SAK=ORXnq5=ZX)!Q<b&|t5mv^6Wc>4u-uXf/yzJUz~mlh{eOD`//x Z#3BhX/b' );
define( 'SECURE_AUTH_KEY',  'tK8wgq=ulq`=CppjiB%aw^]B`W&0:0<j(Y+b3Qxs=(^}N9!oUxe7z~;.b$q>t<_>' );
define( 'LOGGED_IN_KEY',    'ZRDx!3LE^hb3T*qB^4GZm7j`gU{Se#i#ML0Jxtf!,3`qQO>r}L&;o<h3?%ixpRx/' );
define( 'NONCE_KEY',        'sMTo_VcX%S@AU6|TNyXdi,2O=u%F`Q7-U=XYM^31Xri 6NPG^NthK7B^JTHwn1Yt' );
define( 'AUTH_SALT',        'q71$_lGe]d+M6ksu,!A<DVN+`5M2)lR(Wa0&X,7h)|h}n)GYz-s:%H}#+,APH@2p' );
define( 'SECURE_AUTH_SALT', '7@ao?vcXuI~^lG9)kvpd$pIz(ZPF7-%9k{Nv97r{lGO{OdFHmZ*m]<fh)4cC+B2i' );
define( 'LOGGED_IN_SALT',   'ns;o+)@!aUep+KoluMetY(5|LWPgf{ ku(E;+28LSnI~yK?uZcg+BQi]<~v~()V6' );
define( 'NONCE_SALT',       '[R9[htMDn/FD$GIw!3}Lz$xjrkYAL_EA5Fj(J=yf!(TmU?Z?(e19i=QK)wJW6!ZE' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

define( 'AS3CF_AWS_ACCESS_KEY_ID', 'AKIAUKU52PUX3XKTUM6K' );
define( 'AS3CF_AWS_SECRET_ACCESS_KEY', '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' );

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );

define('FS_METHOD', 'direct');

